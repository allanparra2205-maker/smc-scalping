"""
mt5_connector.py — Conector local MT5 → Render API
NO sube a GitHub. Corre desde CMD en tu máquina con MT5.

Uso:
    python mt5_connector.py

Requisitos:
    pip install MetaTrader5 requests python-dotenv
"""

import time
import logging
import os
import requests
from datetime import datetime
from typing import Dict, Optional
from dataclasses import dataclass, field
from dotenv import load_dotenv

load_dotenv()

try:
    import MetaTrader5 as mt5
except ImportError:
    raise SystemExit("ERROR: pip install MetaTrader5")

# ═══════════════════════════════════════════════════════════════
# CONFIGURACIÓN — edita aquí
# ═══════════════════════════════════════════════════════════════

SERVER_URL    = os.environ.get("SERVER_URL", "https://tu-app.onrender.com")
API_SECRET    = os.environ.get("API_SECRET", "")
SYMBOL        = os.environ.get("SYMBOL", "XAUUSD")
TIMEFRAMES    = ["M1", "M5"]
CANDLES_M1    = 120
CANDLES_M5    = 80
LOOP_SECONDS  = 10               # Segundos entre ciclos
COOLDOWN      = 300              # Segundos mínimos entre señales del mismo TF
SCORE_LOG_MIN = 3                # Score SMC mínimo para loggear aunque no sea válido

# ═══════════════════════════════════════════════════════════════
# SESIONES UTC
# ═══════════════════════════════════════════════════════════════

SESSIONS = {
    "Tokio":              (0,  6),
    "Londres":            (7, 12),
    "Overlap Londres-NY": (12, 15),
    "Nueva York":         (13, 21),
    "Sydney":             (21, 24),
}

MT5_TF_MAP = {
    "M1":  mt5.TIMEFRAME_M1,
    "M5":  mt5.TIMEFRAME_M5,
    "M15": mt5.TIMEFRAME_M15,
    "H1":  mt5.TIMEFRAME_H1,
}

# ═══════════════════════════════════════════════════════════════
# LOGGING
# ═══════════════════════════════════════════════════════════════

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("smc_signals.log", encoding="utf-8"),
    ],
)
log = logging.getLogger("MT5")

# ═══════════════════════════════════════════════════════════════
# ESTADO POR TF
# ═══════════════════════════════════════════════════════════════

@dataclass
class TFState:
    last_signal_time: float = 0.0
    last_direction: str = "NEUTRAL"
    signals_total: int = 0
    signals_valid: int = 0


tf_states: Dict[str, TFState] = {tf: TFState() for tf in TIMEFRAMES}

# ═══════════════════════════════════════════════════════════════
# MT5 HELPERS
# ═══════════════════════════════════════════════════════════════

def get_session() -> str:
    h = datetime.utcnow().hour
    for name, (start, end) in SESSIONS.items():
        if start <= h < end:
            return name
    return ""


def get_spread(symbol: str) -> float:
    info = mt5.symbol_info(symbol)
    if not info:
        return 0.0
    return info.spread * info.point


def get_current_price(symbol: str) -> float:
    tick = mt5.symbol_info_tick(symbol)
    if not tick:
        return 0.0
    return round((tick.bid + tick.ask) / 2.0, 5)


def fetch_candles(symbol: str, tf_str: str, count: int) -> list:
    tf = MT5_TF_MAP.get(tf_str.upper())
    if tf is None:
        return []
    rates = mt5.copy_rates_from_pos(symbol, tf, 0, count)
    if rates is None or len(rates) == 0:
        return []
    return [
        {
            "time":   str(r["time"]),
            "open":   float(r["open"]),
            "high":   float(r["high"]),
            "low":    float(r["low"]),
            "close":  float(r["close"]),
            "volume": int(r["tick_volume"]),
        }
        for r in rates
    ]

# ═══════════════════════════════════════════════════════════════
# LLAMADA AL SERVER
# ═══════════════════════════════════════════════════════════════

def call_server(payload: dict) -> Optional[dict]:
    headers = {"Content-Type": "application/json"}
    if API_SECRET:
        headers["x-api-secret"] = API_SECRET

    try:
        resp = requests.post(
            f"{SERVER_URL}/analyze",
            json=payload,
            headers=headers,
            timeout=20,
        )
        resp.raise_for_status()
        return resp.json()
    except requests.exceptions.Timeout:
        log.warning("Timeout en llamada al server")
    except requests.exceptions.ConnectionError:
        log.warning("No se pudo conectar al server — ¿está corriendo Render?")
    except Exception as e:
        log.warning(f"Error llamada server: {e}")
    return None

# ═══════════════════════════════════════════════════════════════
# COOLDOWN
# ═══════════════════════════════════════════════════════════════

def in_cooldown(tf: str) -> bool:
    elapsed = time.time() - tf_states[tf].last_signal_time
    if elapsed < COOLDOWN:
        log.debug(f"[{tf}] Cooldown: {int(COOLDOWN - elapsed)}s restantes")
        return True
    return False

# ═══════════════════════════════════════════════════════════════
# FORMATO DE SEÑAL EN CONSOLA
# ═══════════════════════════════════════════════════════════════

def print_signal(data: dict) -> None:
    emoji = "🟢 BUY" if data["direction"] == "BUY" else "🔴 SELL"
    ai_bar = "★" * max(0, data["score_ai"]) + "☆" * (10 - max(0, data["score_ai"]))
    lines = [
        f"\n{'═'*52}",
        f"  {emoji}  —  {data['symbol']} [{data['timeframe']}]",
        f"{'═'*52}",
        f"  Score SMC : {data['score_smc']}/10",
        f"  Score IA  : {data['score_ai']}/10  {ai_bar}",
        f"  IA dice   : {data['ai_comment']}",
        f"  Entry     : {data['entry']}",
        f"  SL        : {data['sl']}",
        f"  TP1       : {data['tp1']}  (RR {data['rr1']:.1f})",
        f"  TP2       : {data['tp2']}  (RR {data['rr2']:.1f})",
        f"  ATR       : {data['atr']}",
        f"  Zona      : {data['zone']} ({data['zone_pct']:.0f}%)",
        f"  Tendencia : {data['trend']}",
        f"  Swept     : {data['liquidity_swept']}",
        f"  Momentum  : {data['momentum_dir']} ({data['momentum_score']:.0%})",
        f"",
        f"  Confluencias:",
    ]
    for c in data.get("confluencias", []):
        lines.append(f"    • {c}")
    lines.append(f"{'═'*52}\n")
    log.warning("\n".join(lines))

# ═══════════════════════════════════════════════════════════════
# CICLO PRINCIPAL
# ═══════════════════════════════════════════════════════════════

def run(symbol: str) -> None:
    log.info(f"Iniciando — {symbol} | TFs: {TIMEFRAMES} | Server: {SERVER_URL}")
    cycle = 0

    while True:
        cycle += 1
        session = get_session()
        price   = get_current_price(symbol)
        spread  = get_spread(symbol)

        log.info(f"── Ciclo #{cycle} | {symbol} {price} | Sesión: {session or 'CERRADA'} | Spread: {spread:.5f}")

        for tf in TIMEFRAMES:
            n = CANDLES_M1 if tf == "M1" else CANDLES_M5
            candles = fetch_candles(symbol, tf, n)

            if not candles:
                log.warning(f"[{tf}] Sin velas")
                continue

            payload = {
                "symbol":        symbol,
                "timeframe":     tf,
                "candles":       candles,
                "current_price": price,
                "spread":        spread,
                "session":       session,
            }

            data = call_server(payload)
            if data is None:
                continue

            # Log de estado siempre
            log.info(
                f"[{tf}] Dir:{data['direction']} SMC:{data['score_smc']} "
                f"AI:{data['score_ai']} Valid:{data['valid']} | {data['reason']}"
            )

            # Log detallado si score interesante aunque no sea válido
            if data["score_smc"] >= SCORE_LOG_MIN and data["direction"] != "NEUTRAL":
                log.info(
                    f"[{tf}] Entry:{data['entry']} SL:{data['sl']} "
                    f"TP1:{data['tp1']} RR:{data['rr1']}"
                )

            # Señal válida
            if data["valid"]:
                if not in_cooldown(tf):
                    tf_states[tf].last_signal_time = time.time()
                    tf_states[tf].last_direction   = data["direction"]
                    tf_states[tf].signals_total   += 1
                    tf_states[tf].signals_valid   += 1
                    print_signal(data)

        # Stats cada 10 ciclos
        if cycle % 10 == 0:
            for tf in TIMEFRAMES:
                s = tf_states[tf]
                log.info(
                    f"[STATS {tf}] Válidas: {s.signals_valid} | "
                    f"Total: {s.signals_total} | Última: {s.last_direction}"
                )

        time.sleep(LOOP_SECONDS)


# ═══════════════════════════════════════════════════════════════
# ENTRYPOINT
# ═══════════════════════════════════════════════════════════════

def main():
    log.info("Conectando a MT5...")

    if not mt5.initialize():
        raise SystemExit(f"No se pudo conectar a MT5: {mt5.last_error()}")

    log.info(f"MT5 OK: {mt5.terminal_info().name}")

    info = mt5.symbol_info(SYMBOL)
    if info is None:
        mt5.shutdown()
        raise SystemExit(f"Símbolo {SYMBOL} no encontrado")

    if not info.visible:
        mt5.symbol_select(SYMBOL, True)

    log.info(f"Símbolo: {SYMBOL} | Digits: {info.digits}")

    try:
        run(SYMBOL)
    except KeyboardInterrupt:
        log.info("Detenido")
    finally:
        mt5.shutdown()
        log.info("MT5 desconectado")


if __name__ == "__main__":
    main()
